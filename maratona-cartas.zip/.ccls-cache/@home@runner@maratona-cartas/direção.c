#include <stdio.h>
#include <string.h>

int calcular_menor_angulo(const char *A, const char *B) {
    const char *direcoes[] = {"norte", "leste", "sul", "oeste"};
    int angulo[] = {0, 90, 180, 270};

    int angulo_A = 0;
    int angulo_B = 0;
    for (int i = 0; i < 4; ++i) {
        if (strcmp(A, direcoes[i]) == 0) {
            angulo_A = angulo[i];
            break;
        }
    }
    for (int i = 0; i < 4; ++i) {
        if (strcmp(B, direcoes[i]) == 0) {
            angulo_B = angulo[i];
            break;
        }
    }
    int diferenca = (angulo_B - angulo_A + 360) % 360;
    return diferenca;
}

int main() {
    const char *A = "norte";
    const char *B = "leste";
    int resultado = calcular_menor_angulo(A, B);
    printf("Menor ângulo: %d graus\n", resultado);
    return 0;
}