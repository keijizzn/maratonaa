#include <stdio.h>

int main() {
    int N; // Quantidade de números
    scanf("%d", &N);

    int soma = 0; // Inicializa a soma

    for (int i = 0; i < N; ++i) {
        int numero;
        scanf("%d", &numero);

        if (numero == 0) {
            // Se o número for zero, subtrai o último número correto
            soma -= soma % 10;
        } else {
            // Se não for zero, adiciona o número à soma
            soma += numero;
        }
    }

    printf("%d\n", soma); // Imprime a soma correta
    return 0;
}