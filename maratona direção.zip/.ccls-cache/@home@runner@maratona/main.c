#include <stdio.h>
#include <string.h>

// Enumeração para as direções
typedef enum {
    NORTE,
    LESTE,
    SUL,
    OESTE
} Direcao;

// Função para calcular o menor ângulo entre duas direções
int calcular_menor_angulo(const char *A, const char *B);

int main() {
    const char *A = "norte";
    const char *B = "leste";
    int resultado = calcular_menor_angulo(A, B);
    printf("Menor ângulo: %d graus\n", resultado);
    return 0;
}

// Implementação da função calcular_menor_angulo
int calcular_menor_angulo(const char *A, const char *B) {
    Direcao direcao_A, direcao_B;

    // Determina a direção correspondente para A
    if (strcmp(A, "norte") == 0) {
        direcao_A = NORTE;
    } else if (strcmp(A, "leste") == 0) {
        direcao_A = LESTE;
    } else if (strcmp(A, "sul") == 0) {
        direcao_A = SUL;
    } else if (strcmp(A, "oeste") == 0) {
        direcao_A = OESTE;
    } else {
        // Direção inválida
        return -1;
    }

    // Determina a direção correspondente para B
    if (strcmp(B, "norte") == 0) {
        direcao_B = NORTE;
    } else if (strcmp(B, "leste") == 0) {
        direcao_B = LESTE;
    } else if (strcmp(B, "sul") == 0) {
        direcao_B = SUL;
    } else if (strcmp(B, "oeste") == 0) {
        direcao_B = OESTE;
    } else {
        // Direção inválida
        return -1;
    }

    // Array de ângulos correspondentes
    int angulos[] = {0, 90, 180, 270};

    // Cálculo da diferença de ângulo
    int diferenca = (angulos[direcao_B] - angulos[direcao_A] + 360) % 360;
    return diferenca;
}
